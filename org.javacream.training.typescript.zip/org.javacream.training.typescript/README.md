# org.javacream.training.typescript
Training Project for TypeScript
