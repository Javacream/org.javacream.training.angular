console.log("Hello World!")

let o = {message: "H"}
if(o.message){
    console.log("MESSAGE " + o.message)
}
else{
    console.log("NO MESSAGE")
    
}
